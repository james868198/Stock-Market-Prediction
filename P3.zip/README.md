# Stock-Market-Prediction

Program Language:           
Python                      3.6

Libraries:                      
jupyter notebook            1.0.0
TensorFlow                  1.12.0 
scikit-learn                0.20.3
